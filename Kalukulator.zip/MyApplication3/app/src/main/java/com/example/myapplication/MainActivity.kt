package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var display: EditText
    private var currentNumber: String = ""
    private var operator: String? = null
    private var firstNumber: Double? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        display = findViewById(R.id.etDisplay)

        // Tombol angka
        val buttons = listOf(
            R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
            R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9
        )

        buttons.forEach { id ->
            findViewById<Button>(id).setOnClickListener {
                val number = (it as Button).text.toString()
                appendNumber(number)
            }
        }

        // Tombol operasi
        findViewById<Button>(R.id.btnPlus).setOnClickListener { setOperator("+") }
        findViewById<Button>(R.id.btnMinus).setOnClickListener { setOperator("-") }
        findViewById<Button>(R.id.btnMultiply).setOnClickListener { setOperator("*") }
        findViewById<Button>(R.id.btnDivide).setOnClickListener { setOperator("/") }

        // Tombol hasil "="
        findViewById<Button>(R.id.btnEqual).setOnClickListener { calculateResult() }

        // Tombol clear "C"
        findViewById<Button>(R.id.btnClear).setOnClickListener { clear() }
    }

    private fun appendNumber(number: String) {
        currentNumber += number
        display.setText(currentNumber)
    }

    private fun setOperator(op: String) {
        firstNumber = currentNumber.toDoubleOrNull()
        operator = op
        currentNumber = ""
    }

    private fun calculateResult() {
        val secondNumber = currentNumber.toDoubleOrNull()
        if (firstNumber != null && secondNumber != null) {
            val result = when (operator) {
                "+" -> firstNumber!! + secondNumber
                "-" -> firstNumber!! - secondNumber
                "*" -> firstNumber!! * secondNumber
                "/" -> firstNumber!! / secondNumber
                else -> 0.0
            }
            display.setText(result.toString())
            currentNumber = result.toString()
            operator = null
        }
    }

    private fun clear() {
        currentNumber = ""
        firstNumber = null
        operator = null
        display.setText("")
    }
}
